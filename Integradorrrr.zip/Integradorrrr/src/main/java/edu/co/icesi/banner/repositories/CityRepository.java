package edu.co.icesi.banner.repositories;

import edu.co.icesi.banner.entity.City;
import edu.co.icesi.banner.entity.Country;
import edu.co.icesi.banner.entity.Location;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CityRepository extends CrudRepository<City, Integer> {

    //CRUD

}
