package edu.co.icesi.banner.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data



@Entity
@Table(name = "sensor")
public class Sensor {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String typeSensor;
    @Column(name = "state", nullable = false)
    private String name;


    public Sensor() {
    }

    @ManyToOne
    @JoinColumn(name = "palms")
    private Palm palm;





}
