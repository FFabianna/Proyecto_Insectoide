package edu.co.icesi.banner.repositories;

import edu.co.icesi.banner.entity.Palm;
import org.springframework.data.repository.CrudRepository;

public interface PalmRepository extends CrudRepository<Palm, String> {
}
