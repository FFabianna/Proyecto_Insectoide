package edu.co.icesi.banner.repositories;

import edu.co.icesi.banner.entity.Location;
import org.springframework.data.repository.CrudRepository;

public interface LocationRepository extends CrudRepository<Location, String> {
}
