package edu.co.icesi.banner.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "users")
public class User {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private String id;
    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "passwrod", nullable = false)
    private String password;
    @Column (name = "email", nullable = false)
    private String email;

    @ManyToOne
    @JoinColumn(name = "locationUser")
    //@JsonIgnore
    private Location location;

}

