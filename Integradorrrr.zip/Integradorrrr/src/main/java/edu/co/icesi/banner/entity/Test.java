package edu.co.icesi.banner.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.sql.Timestamp;
import java.util.List;
import lombok.Data;



@Data

@Entity
@Table(name = "test")
public class Test {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)


    @Column(name = "horaInicio", nullable = false)
    private Timestamp horaInicio;

    @Column(name = "horaFin", nullable = false)
    private Timestamp horaFin;



    @ManyToOne
    @JoinColumn(name = "sensor")
    //@JsonIgnore
    private Sensor sensor;

}
