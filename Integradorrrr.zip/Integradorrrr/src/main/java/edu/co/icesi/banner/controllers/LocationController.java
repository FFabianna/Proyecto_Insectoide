
package edu.co.icesi.banner.controllers;

import edu.co.icesi.banner.entity.Location;
import edu.co.icesi.banner.entity.User;
import edu.co.icesi.banner.repositories.LocationRepository;
import edu.co.icesi.banner.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(maxAge = 3600)
public class LocationController {

    @Autowired
    private LocationRepository locationRepository;

    @GetMapping(value = "locations")
    public Iterable<Location> getLocations() {
        return locationRepository.findAll();
    }


}


