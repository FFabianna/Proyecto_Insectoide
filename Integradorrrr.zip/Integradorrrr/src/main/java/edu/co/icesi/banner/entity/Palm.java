package edu.co.icesi.banner.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import lombok.Data;

import java.util.List;

@Data



@Entity
@Table(name = "palms")

public class Palm {


    @Id
    @Column(name = "palmnum", nullable = false, updatable = false)
    private String palmnum;
    @Column(name = "state", nullable = false)
    private String state;
    @Column(name = "coordenate", nullable = false)
    private String coordenate;
    @Column (name = "latitude", nullable = false)
    private String latitude;

    @Column (name = "longitude", nullable = false)
    private String longitude;



}
