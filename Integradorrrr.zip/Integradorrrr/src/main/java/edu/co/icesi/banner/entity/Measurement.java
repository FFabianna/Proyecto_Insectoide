package edu.co.icesi.banner.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data

@Entity
@Table(name = "measurement")
public class Measurement {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String sensor;

    @Column(name = "ax", nullable = false)
    private double ax;
    @Column(name = "ay", nullable = false)
    private double ay;
    @Column (name = "az", nullable = false)
    private double az;
    @Column (name = "gx", nullable = false)
    private double gx;

    @Column(name = "gy", nullable = false)
    private double gy;
    @Column (name = "gz", nullable = false)
    private double gz;

    @ManyToOne
    @JoinColumn(name = "test")
    private Test  test;

}
