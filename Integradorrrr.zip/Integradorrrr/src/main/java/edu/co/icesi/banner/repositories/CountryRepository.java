package edu.co.icesi.banner.repositories;

public interface CountryRepository {
}
