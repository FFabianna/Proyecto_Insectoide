
package edu.co.icesi.banner.controllers;
import edu.co.icesi.banner.entity.User;
import edu.co.icesi.banner.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(maxAge = 3600)
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping(value = "users")
    public Iterable<User> getUsers() {
        return userRepository.findAll();
    }

    @PostMapping(value = "users/create", consumes = "application/json")
    public ResponseEntity<?> create(@RequestBody User user) {

        if(userRepository.existsById(user.getId())==false){
            userRepository.save(user);
            return ResponseEntity.status(200).body("Done");
        }
        return ResponseEntity.status(400).body("El usuario ya existe");

    }

    @PostMapping(value = "users/login", consumes = "application/json")
    public ResponseEntity<?> login(@RequestBody User user) {
        String id = user.getId();
        String password = user.getPassword();

        User foundUser = userRepository.findById(id).orElse(null);

        if (foundUser != null) {
            if(foundUser.getPassword().equals(password)){
                return ResponseEntity.ok().body(foundUser);
            }
            return ResponseEntity.status(400).body("El usuario no existe o las credenciales son incorrectas");
        }
        return ResponseEntity.status(400).body("El usuario no existe o la contraseña es incorrecta");
    }


        @DeleteMapping(value = "users/delete", consumes = "application/json")
        public ResponseEntity<?> delete(@RequestBody User user) {
            // Obtén el ID del usuario a eliminar
            String userId = user.getId();
            // Verifica si el usuario existe en el repositorio
            if (userRepository.existsById(userId)) {
                // Si el usuario existe, elimínalo
                userRepository.deleteById(userId);
                return ResponseEntity.status(200).body("El usuario ha sido eliminado correctamente");
            } else {
                // Si el usuario no existe
                return ResponseEntity.status(400).body("El usuario no existe");
            }
        }

        @PostMapping(value = "users/update", consumes = "application/json")
        public ResponseEntity<?> update(@RequestBody User user) {
            // Obtén el ID del usuario a actualizar
            String userId = user.getId();

            // Verifica si el usuario existe en el repositorio
            if (userRepository.existsById(userId)) {
                // Si el usuario existe, actualízalo
                userRepository.save(user);
                return ResponseEntity.status(200).body("El usuario ha sido actualizado correctamente");
            } else {
                // Si el usuario no existe
                return ResponseEntity.status(400).body("El usuario no existe");
            }
        }

}


