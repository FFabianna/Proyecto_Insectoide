
package edu.co.icesi.banner.controllers;

import edu.co.icesi.banner.entity.Palm;
import edu.co.icesi.banner.entity.User;
import edu.co.icesi.banner.repositories.PalmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(maxAge = 3600)
public class PalmController {

    @Autowired
    private PalmRepository palmRepository;

    @GetMapping(value = "palms")
    public Iterable<Palm> getPalms() {
        return palmRepository.findAll();
    }

    @PostMapping(value = "palms/create", consumes = "application/json")
    public ResponseEntity<?> create(@RequestBody Palm palm) {

            if(palmRepository.existsById(palm.getPalmnum())==false){
                palmRepository.save(palm);
                return ResponseEntity.status(200).body("Done");
            }
            return ResponseEntity.status(400).body("El usuario ya existe");

        }
    }

