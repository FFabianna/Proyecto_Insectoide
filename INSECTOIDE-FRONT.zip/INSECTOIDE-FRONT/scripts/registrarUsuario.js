const id = document.getElementById('id');
const email = document.getElementById('email');
const name = document.getElementById('name');
const localidad = document.getElementById('localidad');
const password = document.getElementById('password');
const regBtn = document.getElementById('regBtn');

import { createUser } from './services/services.js';


//arrow function
const registrarse = async () => {
    var userObj = {
        id: id.value,
        name: name.value,
        email: email.value,
        location: {"zone": localidad.value},
        password: password.value,
    }

    const data = await createUser(userObj)

    console.log(data);

}

regBtn.addEventListener('click', registrarse);

