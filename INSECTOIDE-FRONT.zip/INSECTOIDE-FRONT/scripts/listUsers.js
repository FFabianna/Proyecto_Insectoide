import { getUsers } from './services/services.js';

// Función para crear los elementos de la lista de usuarios
function createListItems(users) {
  const userList = document.querySelector('.user-list ul');

  // Eliminar todos los elementos existentes en la lista
  userList.innerHTML = '';

  // Crear elementos de lista para cada usuario
  users.forEach(user => {
    const listItem = document.createElement('li');
    listItem.textContent = user.name;
    userList.appendChild(listItem);
  });
}

// Obtener y mostrar la lista de usuarios al cargar la página
window.addEventListener('DOMContentLoaded', async () => {
  try {
    const users = await getUsers();
    createListItems(users);
  } catch (error) {
    console.error('Error:', error);
  }
});
