const helloText = document.getElementById('hello');


import { createUser } from './services/services.js';

const user=localStorage.getItem('user');
console.log(user);


helloText.innerHTML = `Hola ${user}`;

