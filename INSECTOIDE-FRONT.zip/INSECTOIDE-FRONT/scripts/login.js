const id = document.getElementById('id');
const password = document.getElementById('password');
const regBtn = document.getElementById('regBtn');

import { loginUser } from './services/services.js';

// arrow function
const iniciarSesion = async () => {
  const userObj = {
    id: id.value,
    password: password.value,
  };

  const data=await loginUser(userObj)

  console.log(data);
  localStorage.setItem('userID', data.id);
  localStorage.setItem('user', data.name);
  localStorage.setItem('email', data.email);
  localStorage.setItem('password', data.password);


  //Go to home
  window.location.href = './home.html';


};

regBtn.addEventListener('click', iniciarSesion);
